package in.kafka.producer.model;

import lombok.Data;

@Data
public class Employee {
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String name;
	
}