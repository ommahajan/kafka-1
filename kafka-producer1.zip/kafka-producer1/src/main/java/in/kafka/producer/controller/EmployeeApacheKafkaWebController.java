package in.kafka.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kafka.producer.model.Employee;
import in.kafka.producer.service.KafkaSender;



@RestController
@RequestMapping(value = "/kafka-producer/")
public class EmployeeApacheKafkaWebController {

	@Autowired
	KafkaSender kafkaSender;

	@PostMapping(value = "/employee")
	public String producer(@RequestBody Employee employee) {
		kafkaSender.sendEmployee(employee);

		return "Employee sent to the Kafka Topic testapp topic Successfully";
	}

}