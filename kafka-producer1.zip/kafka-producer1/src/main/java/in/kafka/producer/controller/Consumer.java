package in.kafka.producer.controller;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import in.kafka.producer.model.Employee;
@Component
public class Consumer {
    @KafkaListener(topics = "testapp", groupId = "${spring.kafka.consumer.group-id-1}")
    public void processMessage1(String content){
        System.out.println("Message received from first group : " + content);
    }
    @KafkaListener(topics = "testapp-2", groupId = "${spring.kafka.consumer.group-id-2}")
    public void processMessage2(Employee content){
        System.out.println("Message received from second group : " + content);
    }
}